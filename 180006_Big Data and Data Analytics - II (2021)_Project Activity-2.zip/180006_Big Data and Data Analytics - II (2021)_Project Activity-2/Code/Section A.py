import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')
import warnings
warnings.filterwarnings('ignore')


# In[2]:


train=pd.read_csv('D:\Train.csv')
test=pd.read_csv('D:\Test.csv')


# In[3]:


test.head()


# In[4]:


train.columns


# In[5]:


test.columns


# In[6]:


train.dtypes


# In[7]:


print("Train dataset shape ", train.shape)
train.head()


# In[8]:


print('Test dataset shape', test.shape)
test.head()


# In[9]:


train["Loan_Status"].count()


# In[10]:


train["Loan_Status"].value_counts()


# In[11]:


train['Loan_Status'].value_counts(normalize=True)*100


# In[12]:


train['Loan_Status'].value_counts(normalize=True).plot.bar(title='Loan Status')
plt.ylabel('Loan Applicants ')
plt.xlabel('Status')
plt.show()


# In[13]:


print("The loan of 422(around 69%) people out of 614 was approved.")


# In[14]:


print("Categorical features: These features have categories (Gender, Married, Self_Employed, Credit_History, Loan_Status)")


# In[15]:


train["Gender"].count()


# In[16]:


train['Gender'].value_counts()


# In[17]:


train['Gender'].value_counts(normalize=True)*100


# In[18]:


train['Gender'].value_counts(normalize=True).plot.bar(title ='Gender of loan applicant data')
print("Question 1(a): Find out the number of male and female in loan applicants data.")
plt.xlabel('Gender')
plt.ylabel('Number of loan applicant')
plt.show()


# In[19]:


print("Conclusion of Question 1(a): ")
print( "Gender variable contain Male : 81% Female: 19%")


# In[20]:


train["Married"].count()


# In[21]:


train["Married"].value_counts()


# In[22]:


print("Total number of people: 611")
print("Married: 398")
print("Unmarried: 213")


# In[23]:


train['Married'].value_counts(normalize=True)*100


# In[24]:


print("Question 1(b) Find out the number of married and unmarried loan applicants.")
train['Married'].value_counts(normalize=True).plot.bar(title='Married Status of an applicant')
plt.xlabel('Married Status')
plt.ylabel('Number of loan applicant')
plt.show()


# In[25]:


print("Conclusion  of Question 1(b)")
print("Number of married people : 65%")
print("Number of unmarried people : 35%")


# In[26]:


train["Self_Employed"].count()


# In[27]:


train['Self_Employed'].value_counts()


# In[28]:


train['Self_Employed'].value_counts(normalize=True)*100


# In[29]:


print("Question 1 (c) Find out the overall dependent status in the dataset.")
train['Self_Employed'].value_counts(normalize=True).plot.bar(title='Dependent Status')
plt.xlabel('Dependent Status')
plt.ylabel('Number of loan applicant')
plt.show()


# In[30]:


print("Question 1(c) conclusion: ")
print("Among 582 people only 14% are Self_Employed and rest of the 86% are Not_Self_Employed")


# In[31]:


train["Education"].count()


# In[32]:


train["Education"].value_counts()


# In[33]:


train["Education"].value_counts(normalize=True)*100


# In[34]:


print(" Question 1(d) Find the count how many loan applicants are graduate and non graduate.")
train["Education"].value_counts(normalize=True).plot.bar(title = "Education")
plt.xlabel('Dependent Status')
plt.ylabel('Percentage')
plt.show()


# In[35]:


print("Question 1(d) conclusion ")
print("Total number of People : 614")
print("78% are Graduated and 22% are not Graduated ")


# In[36]:


train["Property_Area"].count()


# In[37]:


train["Property_Area"].value_counts()


# In[38]:


train["Property_Area"].value_counts(normalize=True)*100


# In[39]:


print("Question 1(e) Find out the count how many loan applicants property lies in urban, rural and semi-urban areas.")
train["Property_Area"].value_counts(normalize=True).plot.bar(title="Property_Area")
#plt.xlabel('Dependent Status')
plt.ylabel('Percentage')
plt.show()


# In[40]:


print("Question 1(E) conclusion")
print("38% people from Semiurban area")
print("33% people from Urban area")
print("29% people from Rural area")


# In[41]:


train["Credit_History"].count()


# In[42]:


train["Credit_History"].value_counts()


# In[43]:


train['Credit_History'].value_counts(normalize=True)*100


# In[44]:


train['Credit_History'].value_counts(normalize=True).plot.bar(title='Credit_History')
plt.xlabel('Debt')
plt.ylabel('Percentage')
plt.show()


# In[45]:


print("Question 3")
print("To visualize and plot the distribution plot of all numerical attributes of the given train dataset i.e. ApplicantIncome,  CoApplicantIncome and LoanAmount.     ")


# In[46]:


print("ApplicantIncome distribution")
plt.figure(1)
plt.subplot(121)
sns.distplot(train["ApplicantIncome"]);

plt.subplot(122)
train["ApplicantIncome"].plot.box(figsize=(16,5))
plt.show()


# In[47]:


train.boxplot(column='ApplicantIncome',by="Education" )
plt.suptitle(" ")
plt.show()


# In[48]:


print("Coapplicant Income distribution")
plt.figure(1)
plt.subplot(121)
sns.distplot(train["CoapplicantIncome"]);

plt.subplot(122)
train["CoapplicantIncome"].plot.box(figsize=(16,5))
plt.show()


# In[49]:


print("Loan Amount Variable")
plt.figure(1)
plt.subplot(121)
df=train.dropna()
sns.distplot(df['LoanAmount']);

plt.subplot(122)
train['LoanAmount'].plot.box(figsize=(16,5))

plt.show()


# In[50]:


print("Loan Amount Term Distribution")
plt.figure(1)
plt.subplot(121)
df = train.dropna()
sns.distplot(df["Loan_Amount_Term"]);

plt.subplot(122)
df["Loan_Amount_Term"].plot.box(figsize=(16,5))
plt.show()